<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/private/bootstrap.php';

// Forward request to private handler
require_once HANDLERS_PATH . '/venue_handler.php';
