<?php

require_once $_SERVER['DOCUMENT_ROOT'] . '/private/bootstrap.php';

require_once HANDLERS_PATH . '/production/delete_user.php';
