<?php

require_once $_SERVER['DOCUMENT_ROOT'] . '/private/bootstrap.php';

// Forward the request to the private handler
require_once HANDLERS_PATH . '/signup_handler.php';
?>
