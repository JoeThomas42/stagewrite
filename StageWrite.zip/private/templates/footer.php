<?php ?>

</div> <!-- Close page-wrapper -->


<footer>
    <div id='footer-content'>
        <h3>StageWrite</h3>
        <p>The ultimate stage plot management tool for event production.</p>
    </div>
</footer>

</body>
</html>
